# An integer
int_example = 5
print(type(int_example))
# A float
float_eg = 4.5
print(type(float_eg))
# A string
Str_eg = "Python"
print(type(Str_eg))
# A boolean
bool_eg=True
print(type(bool_eg))

