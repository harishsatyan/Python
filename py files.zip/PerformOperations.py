# Add two integers
int_a = 5
int_b = 6
print(int_a+int_b)
# Concatenate two strings
str_a = "Data"
str_b = "Engineering"
print(str_a+ " " + str_b)
# Multiply a float by an integer
float_a = 4.5
print(float_a*int_a)
# Use a boolean in a comparison (True or False)
flag_check = False
if int_a > int_b:
    flag_check = True
print(flag_check)