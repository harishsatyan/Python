list_eg = [6,2,3,9,5,1]
print(list_eg[0])
print(list_eg[-1])
print(list_eg[3])
list_eg.append(7)
print(list_eg)
list_eg.remove(5)
print(list_eg)
list_eg.pop(2)
print(list_eg)
list_eg.sort()
print(list_eg)
programming_languages = ["Python", "Swift","Java", "C++", "Go", "Rust"]
programming_languages.sort()
print(programming_languages)
diff_list=[5,1,3,'Banana','Apple','JackFruit']
sorted_list = sorted(diff_list, key=str)
print(sorted_list)

